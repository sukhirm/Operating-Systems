mod avoidance;
mod detection;
mod recovery;
mod experiment;

fn main() {
    println!("==================================");
    println!("   DEADLOCK ENGINEERING PROJECT");
    println!("==================================");

    // DEADLOCK AVOIDANCE

    println!("\n[1] DEADLOCK AVOIDANCE");

    let banker = avoidance::Banker::new(
        vec![3, 3, 2],
        vec![
            vec![0, 1, 0],
            vec![2, 0, 0],
            vec![3, 0, 2],
            vec![2, 1, 1],
            vec![0, 0, 2],
        ],
        vec![
            vec![7, 5, 3],
            vec![3, 2, 2],
            vec![9, 0, 2],
            vec![2, 2, 2],
            vec![4, 3, 3],
        ],
    );

    println!(
        "System State: {}",
        if banker.is_safe() { "SAFE" } else { "UNSAFE" }
    );

    // DEADLOCK DETECTION

    println!("\n[2] DEADLOCK DETECTION");

    let mut available = vec![0, 0];

    let mut allocation = vec![
        vec![1, 0],
        vec![0, 1],
    ];

    let mut request = vec![
        vec![0, 1],
        vec![1, 0],
    ];

    let detector = detection::DeadlockDetector::new(
        available.clone(),
        allocation.clone(),
        request.clone(),
    );

    let deadlocked = detector.detect();

    println!("Deadlocked processes: {:?}", deadlocked);

    // DEADLOCK RECOVERY

    println!("\n[3] DEADLOCK RECOVERY");

    if let Some(victim) = recovery::recover(
        &mut available,
        &mut allocation,
        &mut request,
        &deadlocked,
    ) {
        println!("Terminating Process P{}", victim);
        println!("Resources released: {:?}", available);
    }

    // VERIFY RECOVERY

    println!("\n[4] RECOVERY VERIFICATION");

    let verifier = detection::DeadlockDetector::new(
        available,
        allocation,
        request,
    );

    let remaining = verifier.detect();

    if remaining.is_empty() {
        println!("Recovery successful!");
        println!("No deadlock remains.");
    } else {
        println!("Deadlock still exists: {:?}", remaining);
    }
    experiment::run_benchmarks();
}
