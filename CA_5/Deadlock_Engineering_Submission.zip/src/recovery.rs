pub fn recover(
    available: &mut Vec<usize>,
    allocation: &mut Vec<Vec<usize>>,
    request: &mut Vec<Vec<usize>>,
    deadlocked: &[usize],
) -> Option<usize> {

    let victim = *deadlocked.first()?;

    // Release resources held by the victim
    for r in 0..available.len() {
        available[r] += allocation[victim][r];
        allocation[victim][r] = 0;
        request[victim][r] = 0;
    }

    Some(victim)
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_resource_recovery() {
        let mut available = vec![0, 0];

        let mut allocation = vec![
            vec![1, 2],
            vec![3, 4],
        ];

        let mut request = vec![
            vec![1, 1],
            vec![2, 2],
        ];

        let victim = recover(
            &mut available,
            &mut allocation,
            &mut request,
            &[1],
        );

        assert_eq!(victim, Some(1));
        assert_eq!(available, vec![3, 4]);
        assert_eq!(allocation[1], vec![0, 0]);
        assert_eq!(request[1], vec![0, 0]);
    }
}

