pub struct Banker {
    available: Vec<usize>,
    allocation: Vec<Vec<usize>>,
    maximum: Vec<Vec<usize>>,
}

impl Banker {
    pub fn new(
        available: Vec<usize>,
        allocation: Vec<Vec<usize>>,
        maximum: Vec<Vec<usize>>,
    ) -> Self {
        Banker {
            available,
            allocation,
            maximum,
        }
    }

    pub fn is_safe(&self) -> bool {
        let processes = self.allocation.len();
        let resources = self.available.len();

        let mut work = self.available.clone();
        let mut finish = vec![false; processes];

        loop {
            let mut found = false;

            for p in 0..processes {
                if !finish[p] {
                    let can_finish = (0..resources).all(|r| {
                        self.maximum[p][r] - self.allocation[p][r]
                            <= work[r]
                    });

                    if can_finish {
                        for r in 0..resources {
                            work[r] += self.allocation[p][r];
                        }

                        finish[p] = true;
                        found = true;
                    }
                }
            }

            if !found {
                break;
            }
        }

        finish.iter().all(|&finished| finished)
    }
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_safe_state() {
        let banker = Banker::new(
            vec![1],
            vec![vec![1]],
            vec![vec![2]],
        );

        assert!(banker.is_safe());
    }

    #[test]
    fn test_unsafe_state() {
        let banker = Banker::new(
            vec![0],
            vec![vec![1]],
            vec![vec![2]],
        );

        assert!(!banker.is_safe());
    }
}
