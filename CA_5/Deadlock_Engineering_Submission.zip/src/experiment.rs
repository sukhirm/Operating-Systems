use std::fs;
use std::hint::black_box;
use std::time::Instant;

use crate::avoidance::Banker;
use crate::detection::DeadlockDetector;

pub fn run_benchmarks() {
    let sizes = [10, 50, 100, 250, 500];
    let repetitions = 50u32;

    let mut csv = String::from(
        "processes,repetitions,avoidance_avg_ns,detection_avg_ns\n"
    );

    println!("\n========== PERFORMANCE BENCHMARK ==========");

    println!(
        "{:<12} {:<20} {:<20}",
        "Processes", "Avoidance (ns)", "Detection (ns)"
    );

    for &n in &sizes {
        let available = vec![0];
        let allocation = vec![vec![1]; n];

        let maximum: Vec<Vec<usize>> = (0..n)
            .map(|i| vec![n - i])
            .collect();

        let request: Vec<Vec<usize>> = (0..n)
            .map(|i| vec![n - i - 1])
            .collect();

        let banker = Banker::new(
            available.clone(),
            allocation.clone(),
            maximum,
        );

        let detector = DeadlockDetector::new(
            available,
            allocation,
            request,
        );

        let start = Instant::now();

        for _ in 0..repetitions {
            black_box(banker.is_safe());
        }

        let avoidance_time =
            start.elapsed().as_nanos() / repetitions as u128;

        let start = Instant::now();

        for _ in 0..repetitions {
            black_box(detector.detect());
        }

        let detection_time =
            start.elapsed().as_nanos() / repetitions as u128;

        println!(
            "{:<12} {:<20} {:<20}",
            n, avoidance_time, detection_time
        );

        csv.push_str(&format!(
            "{},{},{},{}\n",
            n, repetitions, avoidance_time, detection_time
        ));
    }

    fs::write("results/benchmark.csv", csv)
        .expect("Could not save benchmark results");

    println!("\nCSV saved: results/benchmark.csv");
}
