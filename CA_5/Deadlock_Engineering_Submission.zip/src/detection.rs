pub struct DeadlockDetector {
    available: Vec<usize>,
    allocation: Vec<Vec<usize>>,
    request: Vec<Vec<usize>>,
}

impl DeadlockDetector {
    pub fn new(
        available: Vec<usize>,
        allocation: Vec<Vec<usize>>,
        request: Vec<Vec<usize>>,
    ) -> Self {
        Self {
            available,
            allocation,
            request,
        }
    }

    pub fn detect(&self) -> Vec<usize> {
        let processes = self.allocation.len();
        let resources = self.available.len();

        let mut work = self.available.clone();

        let mut finish: Vec<bool> = self.allocation
            .iter()
            .map(|allocation| allocation.iter().all(|&x| x == 0))
            .collect();

        loop {
            let mut found = false;

            for p in 0..processes {
                if !finish[p] {
                    let can_finish = (0..resources).all(|r| {
                        self.request[p][r] <= work[r]
                    });

                    if can_finish {
                        for r in 0..resources {
                            work[r] += self.allocation[p][r];
                        }

                        finish[p] = true;
                        found = true;
                    }
                }
            }

            if !found {
                break;
            }
        }

        finish.iter()
            .enumerate()
            .filter_map(|(i, &done)| if !done { Some(i) } else { None })
            .collect()
    }
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_no_deadlock() {
        let detector = DeadlockDetector::new(
            vec![1],
            vec![vec![1]],
            vec![vec![1]],
        );

        assert_eq!(detector.detect(), vec![]);
    }

    #[test]
    fn test_deadlock_detected() {
        let detector = DeadlockDetector::new(
            vec![0],
            vec![vec![1], vec![1]],
            vec![vec![1], vec![1]],
        );

        assert_eq!(detector.detect(), vec![0, 1]);
    }
}
